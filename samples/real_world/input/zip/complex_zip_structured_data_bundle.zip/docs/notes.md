# Notes

Use `./samples/check.sh --real-world --tags complex` for long-form scenarios.
