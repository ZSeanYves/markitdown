# Large ZIP

Many entries benchmark.
