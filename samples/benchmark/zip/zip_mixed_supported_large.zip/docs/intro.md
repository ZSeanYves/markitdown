# Mixed ZIP

Mixed supported entries.
