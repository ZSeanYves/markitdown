# Small ZIP

Tiny archive benchmark.
